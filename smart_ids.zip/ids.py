import argparse
from scapy.all import sniff, rdpcap
from detector import packet_handler

def live_mode():
    print("🚨 啟動即時監控模式...")
    sniff(prn=packet_handler, store=False)

def pcap_mode(file_path):
    print(f"📦 載入 PCAP 分析: {file_path}")
    packets = rdpcap(file_path)
    for pkt in packets:
        packet_handler(pkt)

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="智能混合型網路入侵偵測系統")
    parser.add_argument("--mode", choices=["live", "pcap"], required=True, help="執行模式")
    parser.add_argument("--file", help="PCAP 檔案路徑（僅限 pcap 模式）")

    args = parser.parse_args()

    if args.mode == "live":
        live_mode()
    elif args.mode == "pcap":
        if not args.file:
            print("❗ 請指定 --file 路徑")
        else:
            pcap_mode(args.file)
