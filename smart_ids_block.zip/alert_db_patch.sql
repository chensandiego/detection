CREATE TABLE IF NOT EXISTS blocked_ips (
    ip TEXT PRIMARY KEY,
    blocked_at TEXT,
    unblock_at TEXT,
    reason TEXT
);
