from flask import request, redirect
from firewall import list_blocked_ips, unblock_ip

@app.route("/blocked", methods=["GET", "POST"])
def blocked():
    if request.method == "POST":
        ip = request.form.get("ip")
        if ip:
            unblock_ip(ip)
        return redirect("/blocked")
    blocked_list = list_blocked_ips()
    return render_template("blocked.html", blocked_ips=blocked_list)
