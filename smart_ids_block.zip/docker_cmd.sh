#!/bin/bash
python unblock_daemon.py &  # ⏱️ 自動解封守護進程
python ids.py --mode live --web
