import subprocess
import sqlite3
from datetime import datetime, timedelta

WHITELIST = set()
try:
    with open("whitelist.txt") as f:
        WHITELIST = set([line.strip() for line in f if line.strip()])
except:
    pass

def block_ip(ip, reason):
    if ip in WHITELIST or ip.startswith("127.") or ip.startswith("192.168."):
        return
    subprocess.run(["iptables", "-A", "INPUT", "-s", ip, "-j", "DROP"])
    now = datetime.now()
    unblock_time = now + timedelta(minutes=60)
    conn = sqlite3.connect("alerts.db")
    c = conn.cursor()
    c.execute("""
        INSERT OR IGNORE INTO blocked_ips (ip, blocked_at, unblock_at, reason)
        VALUES (?, ?, ?, ?)
    """, (ip, now.strftime("%Y-%m-%d %H:%M:%S"),
           unblock_time.strftime("%Y-%m-%d %H:%M:%S"), reason))
    conn.commit()
    conn.close()

def unblock_ip(ip):
    subprocess.run(["iptables", "-D", "INPUT", "-s", ip, "-j", "DROP"])
    conn = sqlite3.connect("alerts.db")
    c = conn.cursor()
    c.execute("DELETE FROM blocked_ips WHERE ip = ?", (ip,))
    conn.commit()
    conn.close()

def list_blocked_ips():
    conn = sqlite3.connect("alerts.db")
    c = conn.cursor()
    c.execute("SELECT ip, blocked_at, unblock_at, reason FROM blocked_ips")
    results = c.fetchall()
    conn.close()
    return results

def auto_unblock_expired():
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    conn = sqlite3.connect("alerts.db")
    c = conn.cursor()
    c.execute("SELECT ip FROM blocked_ips WHERE unblock_at <= ?", (now,))
    expired = c.fetchall()
    for ip, in expired:
        subprocess.run(["iptables", "-D", "INPUT", "-s", ip, "-j", "DROP"])
        c.execute("DELETE FROM blocked_ips WHERE ip = ?", (ip,))
    conn.commit()
    conn.close()
