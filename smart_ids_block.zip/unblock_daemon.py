import time
from firewall import auto_unblock_expired

if __name__ == "__main__":
    print("🔄 啟動 IP 解封守護進程，每 5 分鐘檢查...")
    while True:
        auto_unblock_expired()
        time.sleep(300)  # 每 5 分鐘執行一次
