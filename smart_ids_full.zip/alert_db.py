import sqlite3
from datetime import datetime
import csv
import requests
import os

LINE_TOKEN = os.environ.get("LINE_TOKEN")
SLACK_WEBHOOK = os.environ.get("SLACK_WEBHOOK")

def init_db():
    conn = sqlite3.connect("alerts.db")
    c = conn.cursor()
    c.execute('''
        CREATE TABLE IF NOT EXISTS alerts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp TEXT,
            src TEXT,
            dst TEXT,
            reason TEXT
        )
    ''')
    conn.commit()
    conn.close()

def insert_alert(src, dst, reason):
    conn = sqlite3.connect("alerts.db")
    c = conn.cursor()
    c.execute("INSERT INTO alerts (timestamp, src, dst, reason) VALUES (?, ?, ?, ?)", 
              (datetime.now().strftime("%Y-%m-%d %H:%M:%S"), src, dst, reason))
    conn.commit()
    conn.close()

def export_to_csv(alert):
    with open("alerts.csv", "a", newline='') as f:
        writer = csv.writer(f)
        writer.writerow([alert["time"], alert["src"], alert["dst"], alert["reason"]])

def notify_line(alert):
    if not LINE_TOKEN: return
    headers = {"Authorization": f"Bearer {LINE_TOKEN}"}
    message = f'【警示】\n時間: {alert["time"]}\n來源: {alert["src"]}\n目標: {alert["dst"]}\n原因: {alert["reason"]}'
    requests.post("https://notify-api.line.me/api/notify", headers=headers, data={"message": message})

def insert_slack(alert):
    if not SLACK_WEBHOOK: return
    message = {
        "text": f'*[入侵警示]* {alert["time"]}\n來源: {alert["src"]} → 目標: {alert["dst"]}\n原因: {alert["reason"]}'
    }
    requests.post(SLACK_WEBHOOK, json=message)
