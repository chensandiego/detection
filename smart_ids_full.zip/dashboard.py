from flask import Flask, render_template
import sqlite3
import threading

app = Flask(__name__)

@app.route("/")
def index():
    conn = sqlite3.connect("alerts.db")
    c = conn.cursor()
    c.execute("SELECT timestamp, src, dst, reason FROM alerts ORDER BY timestamp DESC")
    alerts = c.fetchall()
    conn.close()
    return render_template("index.html", alerts=alerts)

def start_web():
    thread = threading.Thread(target=lambda: app.run(debug=False, port=5000, use_reloader=False))
    thread.start()
